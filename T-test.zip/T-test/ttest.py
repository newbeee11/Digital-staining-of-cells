import os
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from tqdm import tqdm
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr


# =========================
# 路径配置
# =========================
FAKE_DIR = r""   # AI虚拟染色
REAL_DIR = r""   # 真实染色
OUT_DIR  = r""

IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def load_color_image(path):
    """兼容中文路径读取彩色图"""
    img = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"无法读取图像: {path}")
    # OpenCV是BGR，转RGB
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img


def get_image_dict(folder):
    """返回 {文件名: 路径}"""
    folder = Path(folder)
    files = {}
    for p in folder.iterdir():
        if p.is_file() and p.suffix.lower() in IMG_EXTS:
            files[p.name] = p
    return files


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    fake_dict = get_image_dict(FAKE_DIR)
    real_dict = get_image_dict(REAL_DIR)

    common_names = sorted(set(fake_dict.keys()) & set(real_dict.keys()))

    print(f"fake图像数: {len(fake_dict)}")
    print(f"real图像数: {len(real_dict)}")
    print(f"成功匹配数: {len(common_names)}")

    if len(common_names) == 0:
        print("❌ 没有匹配到同名图像，请检查文件名是否一致")
        return

    ssim_list = []
    psnr_list = []
    rows = []

    bad_count = 0

    for name in tqdm(common_names, desc="计算 SSIM / PSNR"):
        fake_path = fake_dict[name]
        real_path = real_dict[name]

        try:
            fake_img = load_color_image(fake_path)
            real_img = load_color_image(real_path)

            if fake_img.shape != real_img.shape:
                print(f"[尺寸不一致，跳过] {name}: fake={fake_img.shape}, real={real_img.shape}")
                bad_count += 1
                continue

            # SSIM：彩色图像直接算，channel_axis=-1
            ssim_val = ssim(real_img, fake_img, channel_axis=-1, data_range=255)

            # PSNR
            psnr_val = psnr(real_img, fake_img, data_range=255)

            ssim_list.append(ssim_val)
            psnr_list.append(psnr_val)

            rows.append({
                "filename": name,
                "ssim": ssim_val,
                "psnr": psnr_val,
            })

        except Exception as e:
            print(f"[错误] {name}: {e}")
            bad_count += 1

    # 保存 txt：一行一个值
    ssim_txt = os.path.join(OUT_DIR, "ssim_list.txt")
    psnr_txt = os.path.join(OUT_DIR, "psnr_list.txt")
    np.savetxt(ssim_txt, np.array(ssim_list), fmt="%.8f")
    np.savetxt(psnr_txt, np.array(psnr_list), fmt="%.8f")

    # 保存 csv：方便后续查每张图的结果
    csv_path = os.path.join(OUT_DIR, "metrics_all.csv")
    df = pd.DataFrame(rows)
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    # 打印统计结果
    print("\n==================== 结果汇总 ====================")
    print(f"有效图像对数: {len(ssim_list)}")
    print(f"跳过/错误数: {bad_count}")
    print(f"平均 SSIM: {np.mean(ssim_list):.6f}")
    print(f"平均 PSNR: {np.mean(psnr_list):.6f}")
    print(f"SSIM 标准差: {np.std(ssim_list, ddof=1):.6f}" if len(ssim_list) > 1 else "SSIM 标准差: N/A")
    print(f"PSNR 标准差: {np.std(psnr_list, ddof=1):.6f}" if len(psnr_list) > 1 else "PSNR 标准差: N/A")
    print(f"\n已保存:")
    print(ssim_txt)
    print(psnr_txt)
    print(csv_path)


if __name__ == "__main__":
    main()